-- ═══════════════════════════════════════════════════════════
--  ΧωριόAlert — Supabase SQL Schema
--  Πήγαινε: Supabase Dashboard → SQL Editor → New Query
--  Αντέγραψε ΟΛΟ αυτό → Run ▶
-- ═══════════════════════════════════════════════════════════

-- ΧΩΡΙΑ
CREATE TABLE IF NOT EXISTS villages (
  id          SERIAL PRIMARY KEY,
  name        TEXT NOT NULL,
  secret_code TEXT NOT NULL UNIQUE,
  lat         DECIMAL(10,7),
  lng         DECIMAL(10,7),
  active      BOOLEAN DEFAULT true,
  created_at  TIMESTAMPTZ DEFAULT NOW()
);

INSERT INTO villages (name, secret_code, lat, lng) VALUES
  ('Απέσια',     'APESIA2024', 34.7200, 32.9800),
  ('Κορφή',      'KORFI2024',  34.9100, 32.8700),
  ('Demo Χωριό', 'DEMO2024',   34.9057, 33.6350)
ON CONFLICT (secret_code) DO NOTHING;

-- ΚΑΤΟΙΚΟΙ
CREATE TABLE IF NOT EXISTS residents (
  id          SERIAL PRIMARY KEY,
  village_id  INT REFERENCES villages(id),
  full_name   TEXT NOT NULL,
  phone       TEXT,
  lat         DECIMAL(10,7),
  lng         DECIMAL(10,7),
  last_seen   TIMESTAMPTZ,
  created_at  TIMESTAMPTZ DEFAULT NOW()
);

-- ΑΝΑΦΟΡΕΣ / ΣΥΜΒΑΝΤΑ
CREATE TABLE IF NOT EXISTS incidents (
  id          SERIAL PRIMARY KEY,
  village_id  INT REFERENCES villages(id),
  user_id     UUID,
  type        TEXT NOT NULL CHECK (type IN ('fire','evacuation','yellow','road','accident','other')),
  severity    TEXT DEFAULT 'medium' CHECK (severity IN ('low','medium','high')),
  description TEXT,
  location    TEXT,
  lat         DECIMAL(10,7),
  lng         DECIMAL(10,7),
  status      TEXT DEFAULT 'active' CHECK (status IN ('active','resolved','false_alarm')),
  created_at  TIMESTAMPTZ DEFAULT NOW(),
  resolved_at TIMESTAMPTZ
);

-- SOS ALERTS
CREATE TABLE IF NOT EXISTS sos_alerts (
  id            SERIAL PRIMARY KEY,
  village_id    INT REFERENCES villages(id),
  user_id       UUID,
  user_name     TEXT,
  lat           DECIMAL(10,7),
  lng           DECIMAL(10,7),
  incident_type TEXT DEFAULT 'general',
  message       TEXT,
  status        TEXT DEFAULT 'active' CHECK (status IN ('active','resolved')),
  created_at    TIMESTAMPTZ DEFAULT NOW()
);

-- ΔΡΟΜΟΙ ΔΙΑΦΥΓΗΣ
CREATE TABLE IF NOT EXISTS routes (
  id         SERIAL PRIMARY KEY,
  village_id INT REFERENCES villages(id),
  name       TEXT NOT NULL,
  status     TEXT DEFAULT 'open' CHECK (status IN ('open','slow','closed')),
  hint       TEXT,
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

INSERT INTO routes (village_id, name, status, hint) VALUES
  (1, 'Δρόμος Λεμεσού Β1',     'open',   '15 λεπτά'),
  (1, 'Παράδρομος Κολοσσίου',  'slow',   'Ελαφρά κίνηση'),
  (1, 'Παλαιός Δρόμος Κ3',     'closed', 'Κλειστός λόγω εργασιών'),
  (2, 'Κεντρικός Δρόμος Α1',   'open',   '10 λεπτά'),
  (2, 'Μονοπάτι Β4',           'open',   '20 λεπτά, εναλλακτική'),
  (2, 'Δρόμος Προς Βούνι',     'slow',   'Προσοχή — στενή λωρίδα'),
  (3, 'Κεντρικός Δρόμος',      'open',   '5 λεπτά'),
  (3, 'Βόρεια Διαδρομή',       'open',   'Μέσω λόφου')
ON CONFLICT DO NOTHING;

-- MAP PINS (σημεία συνάντησης)
CREATE TABLE IF NOT EXISTS map_pins (
  id         SERIAL PRIMARY KEY,
  village_id INT REFERENCES villages(id),
  type       TEXT NOT NULL CHECK (type IN ('meeting','alert','route','hazard')),
  name       TEXT,
  info       TEXT,
  lat        DECIMAL(10,7) NOT NULL,
  lng        DECIMAL(10,7) NOT NULL,
  active     BOOLEAN DEFAULT true
);

INSERT INTO map_pins (village_id, type, name, info, lat, lng) VALUES
  (1, 'meeting', 'Σημείο Συνάντησης Α', 'Κεντρική πλατεία — 200 άτομα', 34.716, 32.975),
  (2, 'meeting', 'Δημοτικό Σχολείο',   'Ασφαλής τοποθεσία',             34.914, 32.875),
  (3, 'meeting', 'Κεντρική Πλατεία',   'Σημείο συνάντησης demo',        34.906, 33.638)
ON CONFLICT DO NOTHING;

-- ═══════════════════════════════════════════════════════════
--  ROW LEVEL SECURITY (RLS) — Ασφάλεια
--  Κάθε κάτοικος βλέπει ΜΟΝΟ τα δεδομένα του χωριού του
-- ═══════════════════════════════════════════════════════════

ALTER TABLE villages   ENABLE ROW LEVEL SECURITY;
ALTER TABLE residents  ENABLE ROW LEVEL SECURITY;
ALTER TABLE incidents  ENABLE ROW LEVEL SECURITY;
ALTER TABLE sos_alerts ENABLE ROW LEVEL SECURITY;
ALTER TABLE routes     ENABLE ROW LEVEL SECURITY;
ALTER TABLE map_pins   ENABLE ROW LEVEL SECURITY;

-- Δημόσια ανάγνωση για villages (για έλεγχο κωδικού)
CREATE POLICY "villages_read" ON villages FOR SELECT USING (true);

-- Residents: ανάγνωση όλων (για χάρτη), εγγραφή δική μας
CREATE POLICY "residents_read"   ON residents FOR SELECT USING (true);
CREATE POLICY "residents_insert" ON residents FOR INSERT WITH CHECK (true);
CREATE POLICY "residents_update" ON residents FOR UPDATE USING (true);

-- Incidents: δημόσια ανάγνωση, εγγραφή από logged-in users
CREATE POLICY "incidents_read"   ON incidents FOR SELECT USING (true);
CREATE POLICY "incidents_insert" ON incidents FOR INSERT WITH CHECK (auth.uid() IS NOT NULL);
CREATE POLICY "incidents_update" ON incidents FOR UPDATE USING (auth.uid() IS NOT NULL);

-- SOS: δημόσια ανάγνωση, εγγραφή από logged-in users
CREATE POLICY "sos_read"   ON sos_alerts FOR SELECT USING (true);
CREATE POLICY "sos_insert" ON sos_alerts FOR INSERT WITH CHECK (auth.uid() IS NOT NULL);

-- Routes & Map Pins: δημόσια ανάγνωση
CREATE POLICY "routes_read"   ON routes   FOR SELECT USING (true);
CREATE POLICY "map_pins_read" ON map_pins FOR SELECT USING (true);
