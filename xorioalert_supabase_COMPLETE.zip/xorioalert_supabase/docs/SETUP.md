# 🚀 ΧωριόAlert — Οδηγός Εγκατάστασης με Supabase
## Από το μηδέν σε λειτουργικό app σε 15 λεπτά

---

## 📁 ΑΡΧΕΙΑ ΠΟΥ ΕΧΕΙΣ

```
xorioalert_supabase/
├── app/
│   └── index.html              ← ΤΟ APP (αυτό ανοίγεις στο browser)
├── database/
│   └── supabase_schema.sql     ← Τρέχεις αυτό στο Supabase
└── docs/
    └── SETUP.md                ← Αυτός ο οδηγός
```

---

## ΒΗΜΑ 1 — Δημιούργησε Supabase Project (5 λεπτά)

1. Πήγαινε στο → **https://supabase.com**
2. Κλίκαρε **"Start your project"**
3. Σύνδεσε με **GitHub** (ή email)
4. Κλίκαρε **"New Project"**
5. Συμπλήρωσε:
   - **Name:** `xorioalert`
   - **Database Password:** (κάτι δυνατό, π.χ. `Xorio@2024!`) — ΑΠΟΘΗΚΕΥΣΕ ΤΟ
   - **Region:** `Europe West (Frankfurt)`
6. Κλίκαρε **"Create new project"**
7. Περίμενε ~2 λεπτά να ετοιμαστεί

---

## ΒΗΜΑ 2 — Δημιούργησε τη Βάση Δεδομένων (2 λεπτά)

1. Στο Supabase dashboard, κλίκαρε **"SQL Editor"** (αριστερά)
2. Κλίκαρε **"New query"**
3. Άνοιξε το αρχείο `database/supabase_schema.sql`
4. Αντέγραψε ΟΛΟ το περιεχόμενο
5. Επικόλλησε στο SQL Editor
6. Κλίκαρε **"Run ▶"** (ή Ctrl+Enter)
7. Πρέπει να δεις: `Success. No rows returned`

---

## ΒΗΜΑ 3 — Πάρε τα API Keys (1 λεπτό)

1. Πήγαινε **Settings** (αριστερά κάτω) → **API**
2. Αντέγραψε:

```
Project URL:   https://XXXXXXXXXXXXXXXX.supabase.co
anon/public:   eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
```

---

## ΒΗΜΑ 4 — Ενημέρωσε το App (1 λεπτό)

Άνοιξε το αρχείο `app/index.html` με Notepad (ή VSCode).

Βρες αυτές τις 2 γραμμές (στην αρχή του `<script>`):

```javascript
const SUPABASE_URL = 'https://ΒΑΛΕ_ΤΟ_URL_ΣΟΥ_ΕΔΩ.supabase.co';
const SUPABASE_KEY = 'ΒΑΛΕ_ΤΟ_ANON_KEY_ΣΟΥ_ΕΔΩ';
```

Αντικατέστησε με τα δικά σου:

```javascript
const SUPABASE_URL = 'https://abcdefgh.supabase.co';      // ← το δικό σου URL
const SUPABASE_KEY = 'eyJhbGciOiJIUzI1NiIsIn...';         // ← το δικό σου key
```

Αποθήκευσε το αρχείο.

---

## ΒΗΜΑ 5 — Ενεργοποίησε Authentication (1 λεπτό)

1. Στο Supabase → **Authentication** → **Providers**
2. **Email** → βεβαιώσου ότι είναι **Enabled**
3. **Authentication** → **URL Configuration**
4. Site URL: `http://localhost` (αλλάζεις αργότερα με το domain σου)
5. Κλίκαρε **Save**

---

## ΒΗΜΑ 6 — Άνοιξε το App!

Απλά κάνε **διπλό κλικ** στο `app/index.html` — ανοίγει στο browser σου!

### Demo Δοκιμή:
- Κλίκαρε **"Δημιουργία Λογαριασμού"**
- Κωδικός χωριού: **`DEMO2024`** (ή `APESIA2024` ή `KORFI2024`)
- Συμπλήρωσε email και κωδικό (6+ χαρακτήρες)
- Κλίκαρε εγγραφή — θα συνδεθεί στη REAL Supabase βάση!

---

## ΒΗΜΑ 7 — Ανέβασε online (προαιρετικό, δωρεάν)

Αν θέλεις να μοιραστείς το app με κατοίκους χωρίς να στέλνεις αρχείο:

### Επιλογή Α — Netlify (πιο εύκολο):
1. Πήγαινε → **https://netlify.com**
2. Drag & drop τον φάκελο `app/` στη σελίδα
3. Έτοιμο! Παίρνεις URL όπως: `https://xorioalert.netlify.app`

### Επιλογή Β — GitHub Pages (δωρεάν):
1. Δημιούργησε repo στο GitHub
2. Ανέβασε τον φάκελο `app/`
3. Settings → Pages → Enable
4. URL: `https://username.github.io/xorioalert`

---

## 🔑 ΚΩΔΙΚΟΙ ΧΩΡΙΩΝ (Demo)

| Χωριό | Κωδικός |
|-------|---------|
| Απέσια | `APESIA2024` |
| Κορφή | `KORFI2024` |
| Demo Χωριό | `DEMO2024` |

Για να προσθέσεις νέο χωριό:
- Supabase → Table Editor → villages → Insert row
- Βάλε όνομα, secret_code, lat/lng

---

## ❓ ΣΥΝΗΘΗ ΠΡΟΒΛΗΜΑΤΑ

**"Invalid API key"**
→ Έλεγξε ότι αντέγραψες σωστά το `anon key` (όχι το `service_role key`)

**"relation does not exist"**
→ Δεν τρέχτηκε το schema.sql. Πήγαινε SQL Editor και τρέξε το ξανά.

**Δεν αποθηκεύει εγγραφή**
→ Authentication → Providers → Email → βεβαιώσου ότι είναι ON

**Ο χάρτης δεν εμφανίζεται**
→ Κάνε κλικ "Εντοπισμός Θέσης" ή δοκίμασε σε Chrome/Firefox

---

## 📱 ΓΙΑ PLAY STORE (επόμενο βήμα)

Όταν είσαι έτοιμος για Android app:
1. Εγκατάστησε **Node.js** από nodejs.org
2. `npm install -g @capacitor/cli`
3. `npx cap init "ΧωριόAlert" "cy.xorioalert.app" --web-dir app`
4. `npx cap add android`
5. `npx cap open android` → Android Studio → Build APK
