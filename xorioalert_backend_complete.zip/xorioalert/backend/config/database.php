<?php
// ═══════════════════════════════════════════════════════
//  config/database.php — Σύνδεση MySQL
//  ΑΛΛΑΞΕ τα παρακάτω με τα στοιχεία του server σου
// ═══════════════════════════════════════════════════════

define('DB_HOST', 'localhost');
define('DB_NAME', 'xorioalert');
define('DB_USER', 'xorioalert_user');   // ← άλλαξε
define('DB_PASS', 'STRONG_PASSWORD');   // ← άλλαξε
define('DB_CHARSET', 'utf8mb4');

define('JWT_SECRET', 'CHANGE_THIS_TO_RANDOM_64_CHAR_STRING'); // ← άλλαξε

function getDB(): PDO {
    static $pdo = null;
    if ($pdo === null) {
        $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET;
        $options = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ];
        $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
    }
    return $pdo;
}
