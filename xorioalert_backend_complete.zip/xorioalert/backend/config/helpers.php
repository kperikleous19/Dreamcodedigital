<?php
// ═══════════════════════════════════════════════════════
//  config/helpers.php — JWT + Response helpers
// ═══════════════════════════════════════════════════════

require_once __DIR__ . '/database.php';

// ── CORS Headers ──────────────────────────────────────
function setCORS(): void {
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
    header('Access-Control-Allow-Headers: Content-Type, Authorization');
    if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(204); exit; }
    header('Content-Type: application/json; charset=utf-8');
}

// ── JSON Responses ─────────────────────────────────────
function respond(array $data, int $code = 200): void {
    http_response_code($code);
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

function error(string $msg, int $code = 400): void {
    respond(['success' => false, 'error' => $msg], $code);
}

function success(array $data = [], string $msg = 'OK'): void {
    respond(['success' => true, 'message' => $msg, 'data' => $data]);
}

// ── Simple JWT (HS256) ─────────────────────────────────
function jwtEncode(array $payload): string {
    $header  = base64url(json_encode(['alg'=>'HS256','typ'=>'JWT']));
    $payload = base64url(json_encode($payload));
    $sig     = base64url(hash_hmac('sha256', "$header.$payload", JWT_SECRET, true));
    return "$header.$payload.$sig";
}

function jwtDecode(string $token): ?array {
    $parts = explode('.', $token);
    if (count($parts) !== 3) return null;
    [$h, $p, $s] = $parts;
    $expected = base64url(hash_hmac('sha256', "$h.$p", JWT_SECRET, true));
    if (!hash_equals($expected, $s)) return null;
    $payload = json_decode(base64_decode(strtr($p, '-_', '+/')), true);
    if (!$payload || (isset($payload['exp']) && $payload['exp'] < time())) return null;
    return $payload;
}

function base64url(string $data): string {
    return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
}

// ── Auth Middleware ────────────────────────────────────
function requireAuth(): array {
    $auth = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
    if (!preg_match('/^Bearer\s+(.+)$/i', $auth, $m)) error('Δεν βρέθηκε token', 401);
    $payload = jwtDecode($m[1]);
    if (!$payload) error('Μη έγκυρο ή ληγμένο token', 401);
    return $payload;
}

// ── Get JSON body ─────────────────────────────────────
function getBody(): array {
    $raw = file_get_contents('php://input');
    return json_decode($raw, true) ?? [];
}
