<?php
// ═══════════════════════════════════════════════════════
//  api/auth.php
//  POST /api/auth.php?action=register
//  POST /api/auth.php?action=login
// ═══════════════════════════════════════════════════════

require_once __DIR__ . '/../config/helpers.php';
setCORS();

$action = $_GET['action'] ?? '';
$body   = getBody();

// ── REGISTER ──────────────────────────────────────────
if ($action === 'register') {
    $name     = trim($body['full_name']    ?? '');
    $email    = strtolower(trim($body['email'] ?? ''));
    $phone    = trim($body['phone']        ?? '');
    $code     = strtoupper(trim($body['village_code'] ?? ''));
    $password = $body['password']          ?? '';

    if (!$name || !$email || !$code || !$password)
        error('Παρακαλώ συμπλήρωσε όλα τα πεδία');
    if (!filter_var($email, FILTER_VALIDATE_EMAIL))
        error('Μη έγκυρο email');
    if (strlen($password) < 6)
        error('Ο κωδικός πρέπει να έχει τουλάχιστον 6 χαρακτήρες');

    $db = getDB();

    // Check village code
    $village = $db->prepare('SELECT id, name FROM villages WHERE secret_code = ? AND active = 1');
    $village->execute([$code]);
    $village = $village->fetch();
    if (!$village) error('Ο κωδικός χωριού δεν είναι έγκυρος');

    // Check email unique
    $exists = $db->prepare('SELECT id FROM users WHERE email = ?');
    $exists->execute([$email]);
    if ($exists->fetch()) error('Το email χρησιμοποιείται ήδη');

    // Create user
    $hash = password_hash($password, PASSWORD_BCRYPT);
    $stmt = $db->prepare('INSERT INTO users (village_id, full_name, email, phone, password_hash) VALUES (?,?,?,?,?)');
    $stmt->execute([$village['id'], $name, $email, $phone, $hash]);
    $userId = $db->lastInsertId();

    $token = jwtEncode([
        'sub'        => $userId,
        'email'      => $email,
        'village_id' => $village['id'],
        'role'       => 'resident',
        'exp'        => time() + 30 * 86400,  // 30 days
    ]);

    success([
        'token'   => $token,
        'user'    => ['id' => $userId, 'name' => $name, 'email' => $email, 'phone' => $phone],
        'village' => ['id' => $village['id'], 'name' => $village['name']],
    ], 'Εγγραφή επιτυχής!');
}

// ── LOGIN ─────────────────────────────────────────────
elseif ($action === 'login') {
    $email    = strtolower(trim($body['email']    ?? ''));
    $password = $body['password'] ?? '';

    if (!$email || !$password) error('Συμπλήρωσε email και κωδικό');

    $db   = getDB();
    $stmt = $db->prepare('SELECT u.*, v.name AS village_name FROM users u JOIN villages v ON u.village_id = v.id WHERE u.email = ? AND u.active = 1');
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    if (!$user || !password_verify($password, $user['password_hash']))
        error('Λάθος email ή κωδικός', 401);

    // Update last_seen
    $db->prepare('UPDATE users SET last_seen = NOW() WHERE id = ?')->execute([$user['id']]);

    $token = jwtEncode([
        'sub'        => $user['id'],
        'email'      => $user['email'],
        'village_id' => $user['village_id'],
        'role'       => $user['role'],
        'exp'        => time() + 30 * 86400,
    ]);

    success([
        'token' => $token,
        'user'  => [
            'id'    => $user['id'],
            'name'  => $user['full_name'],
            'email' => $user['email'],
            'phone' => $user['phone'],
            'role'  => $user['role'],
        ],
        'village' => [
            'id'   => $user['village_id'],
            'name' => $user['village_name'],
        ],
    ], 'Σύνδεση επιτυχής');
}

else {
    error('Άγνωστη ενέργεια', 404);
}
