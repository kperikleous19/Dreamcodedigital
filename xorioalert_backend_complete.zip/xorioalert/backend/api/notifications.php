<?php
// ═══════════════════════════════════════════════════════
//  api/notifications.php
//  GET  /api/notifications.php      → ιστορικό notifications χωριού
//  POST /api/notifications.php      → αποστολή (owner μόνο)
// ═══════════════════════════════════════════════════════

require_once __DIR__ . '/../config/helpers.php';
setCORS();

$auth   = requireAuth();
$method = $_SERVER['REQUEST_METHOD'];
$db     = getDB();

if ($method === 'GET') {
    $stmt = $db->prepare('
        SELECT * FROM notifications
        WHERE village_id = ?
        ORDER BY sent_at DESC
        LIMIT 30
    ');
    $stmt->execute([$auth['village_id']]);
    success($stmt->fetchAll());
}

elseif ($method === 'POST') {
    if (!in_array($auth['role'], ['owner','admin']))
        error('Μόνο ο owner μπορεί να στείλει notifications', 403);

    $body  = getBody();
    $title = $body['title'] ?? '';
    $text  = $body['body']  ?? '';
    $type  = $body['type']  ?? 'info';

    if (!$title) error('Απαιτείται τίτλος');

    $db->prepare('INSERT INTO notifications (village_id, title, body, type) VALUES (?,?,?,?)')
       ->execute([$auth['village_id'], $title, $text, $type]);

    // TODO: Firebase push σε όλους τους κατοίκους του χωριού
    $tokens = $db->prepare('SELECT fcm_token FROM users WHERE village_id=? AND fcm_token IS NOT NULL AND active=1');
    $tokens->execute([$auth['village_id']]);
    $tokenList = array_column($tokens->fetchAll(), 'fcm_token');
    // sendFirebasePush($tokenList, $title, $text);

    success(['recipients' => count($tokenList)], 'Notification εστάλη');
}

else {
    error('Μέθοδος δεν υποστηρίζεται', 405);
}
