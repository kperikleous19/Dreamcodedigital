<?php
// ═══════════════════════════════════════════════════════
//  api/map.php
//  GET /api/map.php               → pins + routes χωριού
//  GET /api/map.php?type=routes   → μόνο δρόμοι
//  PUT /api/map.php?route=X       → ενημέρωση δρόμου (owner)
//  POST /api/map.php?action=location → ενημέρωση θέσης χρήστη
// ═══════════════════════════════════════════════════════

require_once __DIR__ . '/../config/helpers.php';
setCORS();

$auth   = requireAuth();
$method = $_SERVER['REQUEST_METHOD'];
$db     = getDB();
$type   = $_GET['type']   ?? 'all';
$action = $_GET['action'] ?? '';

// ── POST: Ενημέρωση θέσης χρήστη ─────────────────────
if ($method === 'POST' && $action === 'location') {
    $body = getBody();
    $lat  = $body['lat'] ?? null;
    $lng  = $body['lng'] ?? null;
    if (!$lat || !$lng) error('Λείπουν συντεταγμένες');

    $db->prepare('UPDATE users SET lat=?, lng=?, last_seen=NOW() WHERE id=?')
       ->execute([$lat, $lng, $auth['sub']]);
    success([], 'Θέση ενημερώθηκε');
}

// ── GET: Χάρτης ───────────────────────────────────────
elseif ($method === 'GET') {

    // Δρόμοι διαφυγής
    $routes = $db->prepare('SELECT * FROM routes WHERE village_id = ? ORDER BY name');
    $routes->execute([$auth['village_id']]);
    $routes = $routes->fetchAll();

    if ($type === 'routes') {
        success(['routes' => $routes]);
    }

    // Map pins (σημεία συνάντησης κλπ)
    $pins = $db->prepare('SELECT * FROM map_pins WHERE village_id = ? AND active = 1');
    $pins->execute([$auth['village_id']]);
    $pins = $pins->fetchAll();

    // Online κάτοικοι (είδαν app τελευταία 10 λεπτά)
    $residents = $db->prepare('
        SELECT id, full_name, lat, lng, last_seen
        FROM users
        WHERE village_id = ? AND lat IS NOT NULL
          AND last_seen > DATE_SUB(NOW(), INTERVAL 10 MINUTE)
          AND active = 1
    ');
    $residents->execute([$auth['village_id']]);
    $residents = $residents->fetchAll();

    // Ενεργά SOS
    $sos = $db->prepare('
        SELECT s.id, s.lat, s.lng, s.incident_type, s.created_at, u.full_name
        FROM sos_alerts s JOIN users u ON s.user_id = u.id
        WHERE s.village_id = ? AND s.status = "active"
    ');
    $sos->execute([$auth['village_id']]);
    $sos = $sos->fetchAll();

    // Ενεργά incidents για χάρτη
    $incidents = $db->prepare('
        SELECT id, type, lat, lng, description, created_at
        FROM incidents
        WHERE village_id = ? AND status = "active" AND lat IS NOT NULL
    ');
    $incidents->execute([$auth['village_id']]);
    $incidents = $incidents->fetchAll();

    success([
        'routes'    => $routes,
        'pins'      => $pins,
        'residents' => $residents,
        'sos'       => $sos,
        'incidents' => $incidents,
    ]);
}

// ── PUT: Ενημέρωση δρόμου (μόνο owner/admin) ─────────
elseif ($method === 'PUT') {
    if (!in_array($auth['role'], ['owner','admin']))
        error('Μόνο ο owner μπορεί να ενημερώσει δρόμους', 403);

    $routeId = (int)($_GET['route'] ?? 0);
    $body    = getBody();
    $status  = $body['status'] ?? '';
    $hint    = $body['hint']   ?? '';

    if (!$routeId || !in_array($status, ['open','slow','closed']))
        error('Μη έγκυρα δεδομένα');

    $db->prepare('UPDATE routes SET status=?, hint=?, updated_by=? WHERE id=? AND village_id=?')
       ->execute([$status, $hint, $auth['sub'], $routeId, $auth['village_id']]);

    success([], 'Δρόμος ενημερώθηκε');
}

else {
    error('Μέθοδος δεν υποστηρίζεται', 405);
}
