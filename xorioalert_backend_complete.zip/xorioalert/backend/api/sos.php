<?php
// ═══════════════════════════════════════════════════════
//  api/sos.php
//  POST /api/sos.php          → αποστολή SOS
//  GET  /api/sos.php          → ενεργά SOS χωριού
//  PUT  /api/sos.php?id=X     → επίλυση SOS
// ═══════════════════════════════════════════════════════

require_once __DIR__ . '/../config/helpers.php';
setCORS();

$auth   = requireAuth();
$method = $_SERVER['REQUEST_METHOD'];
$db     = getDB();

// ── GET: Ενεργά SOS ───────────────────────────────────
if ($method === 'GET') {
    $stmt = $db->prepare('
        SELECT s.*, u.full_name, u.phone
        FROM sos_alerts s
        JOIN users u ON s.user_id = u.id
        WHERE s.village_id = ? AND s.status = "active"
        ORDER BY s.created_at DESC
    ');
    $stmt->execute([$auth['village_id']]);
    success($stmt->fetchAll());
}

// ── POST: Νέο SOS ─────────────────────────────────────
elseif ($method === 'POST') {
    $body = getBody();
    $lat  = $body['lat']           ?? null;
    $lng  = $body['lng']           ?? null;
    $type = $body['incident_type'] ?? 'general';
    $msg  = $body['message']       ?? '';

    $stmt = $db->prepare('
        INSERT INTO sos_alerts (village_id, user_id, lat, lng, incident_type, message)
        VALUES (?,?,?,?,?,?)
    ');
    $stmt->execute([$auth['village_id'], $auth['sub'], $lat, $lng, $type, $msg]);
    $sosId = $db->lastInsertId();

    // Βρες κοντινούς κατοίκους (αν έχουν lat/lng)
    $nearby = [];
    if ($lat && $lng) {
        $stmt2 = $db->prepare('
            SELECT id, full_name, phone, fcm_token,
                   (6371 * ACOS(COS(RADIANS(?)) * COS(RADIANS(lat)) *
                    COS(RADIANS(lng) - RADIANS(?)) + SIN(RADIANS(?)) * SIN(RADIANS(lat)))) AS distance_km
            FROM users
            WHERE village_id = ? AND id != ? AND lat IS NOT NULL AND active = 1
            HAVING distance_km < 2
            ORDER BY distance_km
            LIMIT 5
        ');
        $stmt2->execute([$lat, $lng, $lat, $auth['village_id'], $auth['sub']]);
        $nearby = $stmt2->fetchAll();
    }

    // Αποθήκευση notification
    $db->prepare('
        INSERT INTO notifications (village_id, title, body, type, data)
        VALUES (?,?,?,?,?)
    ')->execute([
        $auth['village_id'],
        '🆘 SOS Alert!',
        'Κάτοικος χρειάζεται άμεση βοήθεια',
        'sos',
        json_encode(['sos_id' => $sosId, 'lat' => $lat, 'lng' => $lng])
    ]);

    // Εδώ θα στέλνες Firebase push notifications στα fcm_tokens
    // sendFirebasePush($nearby, 'SOS Alert', '...');

    success([
        'sos_id'          => $sosId,
        'nearby_residents' => count($nearby),
        'notified'        => array_map(fn($u) => $u['full_name'], $nearby),
    ], 'SOS εστάλη! Ειδοποιήθηκαν ' . count($nearby) . ' κοντινοί κάτοικοι.');
}

// ── PUT: Επίλυση SOS ──────────────────────────────────
elseif ($method === 'PUT') {
    $id = (int)($_GET['id'] ?? 0);
    if (!$id) error('Μη έγκυρο ID');

    $db->prepare('UPDATE sos_alerts SET status = "resolved" WHERE id = ? AND village_id = ?')
       ->execute([$id, $auth['village_id']]);
    success([], 'SOS επιλύθηκε');
}

else {
    error('Μέθοδος δεν υποστηρίζεται', 405);
}
