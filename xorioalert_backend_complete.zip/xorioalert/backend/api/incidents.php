<?php
// ═══════════════════════════════════════════════════════
//  api/incidents.php
//  GET    /api/incidents.php          → λίστα συμβάντων χωριού
//  POST   /api/incidents.php          → νέο συμβάν
//  PUT    /api/incidents.php?id=X     → ενημέρωση κατάστασης
// ═══════════════════════════════════════════════════════

require_once __DIR__ . '/../config/helpers.php';
setCORS();

$auth   = requireAuth();
$method = $_SERVER['REQUEST_METHOD'];
$db     = getDB();

// ── GET: Λίστα ενεργών συμβάντων χωριού ──────────────
if ($method === 'GET') {
    $stmt = $db->prepare('
        SELECT i.*, u.full_name AS reporter_name
        FROM incidents i
        JOIN users u ON i.user_id = u.id
        WHERE i.village_id = ?
        ORDER BY i.created_at DESC
        LIMIT 50
    ');
    $stmt->execute([$auth['village_id']]);
    success($stmt->fetchAll());
}

// ── POST: Νέο συμβάν ──────────────────────────────────
elseif ($method === 'POST') {
    $body = getBody();
    $type        = $body['type']        ?? '';
    $severity    = $body['severity']    ?? 'medium';
    $description = $body['description'] ?? '';
    $location    = $body['location']    ?? '';
    $lat         = $body['lat']         ?? null;
    $lng         = $body['lng']         ?? null;

    $allowed = ['fire','evacuation','yellow','road','accident','other'];
    if (!in_array($type, $allowed)) error('Μη έγκυρος τύπος συμβάντος');

    $stmt = $db->prepare('
        INSERT INTO incidents (village_id, user_id, type, severity, description, location, lat, lng)
        VALUES (?,?,?,?,?,?,?,?)
    ');
    $stmt->execute([
        $auth['village_id'], $auth['sub'],
        $type, $severity, $description, $location, $lat, $lng
    ]);
    $incidentId = $db->lastInsertId();

    // Αποθήκευση notification
    $db->prepare('
        INSERT INTO notifications (village_id, title, body, type, data)
        VALUES (?,?,?,?,?)
    ')->execute([
        $auth['village_id'],
        "Νέα αναφορά: " . ucfirst($type),
        $description ?: "Αναφορά από κάτοικο",
        $type,
        json_encode(['incident_id' => $incidentId, 'lat' => $lat, 'lng' => $lng])
    ]);

    success(['incident_id' => $incidentId], 'Η αναφορά εστάλη!');
}

// ── PUT: Ενημέρωση κατάστασης ─────────────────────────
elseif ($method === 'PUT') {
    $id     = (int)($_GET['id'] ?? 0);
    $body   = getBody();
    $status = $body['status'] ?? '';

    $allowed = ['active','resolved','false_alarm'];
    if (!$id || !in_array($status, $allowed)) error('Μη έγκυρα δεδομένα');

    // Μόνο owner/admin ή ο ίδιος ο reporter
    $inc = $db->prepare('SELECT user_id FROM incidents WHERE id = ? AND village_id = ?');
    $inc->execute([$id, $auth['village_id']]);
    $inc = $inc->fetch();
    if (!$inc) error('Δεν βρέθηκε το συμβάν', 404);
    if ($auth['role'] === 'resident' && $inc['user_id'] !== $auth['sub'])
        error('Δεν έχεις δικαίωμα', 403);

    $resolved = ($status === 'resolved') ? 'NOW()' : 'NULL';
    $db->prepare("UPDATE incidents SET status = ?, resolved_at = $resolved WHERE id = ?")
       ->execute([$status, $id]);

    success([], 'Ενημερώθηκε');
}

else {
    error('Μέθοδος δεν υποστηρίζεται', 405);
}
