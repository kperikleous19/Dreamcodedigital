-- ═══════════════════════════════════════════════════════════
--  ΧωριόAlert — MySQL Database Schema
--  Εκτέλεσε αυτό στο phpMyAdmin ή με: mysql -u root -p < schema.sql
-- ═══════════════════════════════════════════════════════════

CREATE DATABASE IF NOT EXISTS xorioalert CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE xorioalert;

-- ─────────────────────────────────────────────────────────
--  VILLAGES — Κοινότητες
-- ─────────────────────────────────────────────────────────
CREATE TABLE villages (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  name        VARCHAR(100) NOT NULL,
  secret_code VARCHAR(32)  NOT NULL UNIQUE,   -- κωδικός από τον owner
  lat         DECIMAL(10,7),
  lng         DECIMAL(10,7),
  owner_email VARCHAR(150),
  active      TINYINT(1) DEFAULT 1,
  created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Αρχικά χωριά (demo)
INSERT INTO villages (name, secret_code, lat, lng, owner_email) VALUES
  ('Απέσια',      'APESIA2024', 34.7200, 32.9800, 'owner@apesia.cy'),
  ('Κορφή',       'KORFI2024',  34.9100, 32.8700, 'owner@korfi.cy'),
  ('Demo Χωριό',  'DEMO2024',   34.9057, 33.6350, 'demo@test.com');

-- ─────────────────────────────────────────────────────────
--  USERS — Κάτοικοι
-- ─────────────────────────────────────────────────────────
CREATE TABLE users (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  village_id    INT NOT NULL,
  full_name     VARCHAR(150) NOT NULL,
  email         VARCHAR(150) NOT NULL UNIQUE,
  phone         VARCHAR(30),
  password_hash VARCHAR(255) NOT NULL,           -- bcrypt
  role          ENUM('resident','owner','admin') DEFAULT 'resident',
  fcm_token     VARCHAR(255),                    -- Firebase push notifications
  lat           DECIMAL(10,7),                   -- τελευταία γνωστή θέση
  lng           DECIMAL(10,7),
  last_seen     TIMESTAMP NULL,
  active        TINYINT(1) DEFAULT 1,
  created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (village_id) REFERENCES villages(id)
);

-- ─────────────────────────────────────────────────────────
--  SESSIONS — JWT tokens (προαιρετικό αν θες server-side)
-- ─────────────────────────────────────────────────────────
CREATE TABLE sessions (
  id         INT AUTO_INCREMENT PRIMARY KEY,
  user_id    INT NOT NULL,
  token      VARCHAR(512) NOT NULL,
  expires_at TIMESTAMP NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ─────────────────────────────────────────────────────────
--  INCIDENTS — Αναφορές / Συμβάντα
-- ─────────────────────────────────────────────────────────
CREATE TABLE incidents (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  village_id  INT NOT NULL,
  user_id     INT NOT NULL,
  type        ENUM('fire','evacuation','yellow','road','accident','other') NOT NULL,
  severity    ENUM('low','medium','high') DEFAULT 'medium',
  description TEXT,
  location    VARCHAR(255),
  lat         DECIMAL(10,7),
  lng         DECIMAL(10,7),
  status      ENUM('active','resolved','false_alarm') DEFAULT 'active',
  created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  resolved_at TIMESTAMP NULL,
  FOREIGN KEY (village_id) REFERENCES villages(id),
  FOREIGN KEY (user_id)    REFERENCES users(id)
);

-- ─────────────────────────────────────────────────────────
--  SOS ALERTS — Κουμπί SOS
-- ─────────────────────────────────────────────────────────
CREATE TABLE sos_alerts (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  village_id  INT NOT NULL,
  user_id     INT NOT NULL,
  lat         DECIMAL(10,7),
  lng         DECIMAL(10,7),
  incident_type VARCHAR(50),
  message     TEXT,
  status      ENUM('active','resolved') DEFAULT 'active',
  created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (village_id) REFERENCES villages(id),
  FOREIGN KEY (user_id)    REFERENCES users(id)
);

-- ─────────────────────────────────────────────────────────
--  ROUTES — Δρόμοι Διαφυγής ανά χωριό
-- ─────────────────────────────────────────────────────────
CREATE TABLE routes (
  id         INT AUTO_INCREMENT PRIMARY KEY,
  village_id INT NOT NULL,
  name       VARCHAR(150) NOT NULL,
  status     ENUM('open','slow','closed') DEFAULT 'open',
  hint       VARCHAR(255),
  updated_by INT,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (village_id) REFERENCES villages(id),
  FOREIGN KEY (updated_by) REFERENCES users(id)
);

INSERT INTO routes (village_id, name, status, hint) VALUES
  (1, 'Δρόμος Λεμεσού Β1',       'open',   '15 λεπτά'),
  (1, 'Παράδρομος Κολοσσίου',    'slow',   'Ελαφρά κίνηση'),
  (1, 'Παλαιός Δρόμος Κ3',       'closed', 'Κλειστός λόγω εργασιών'),
  (2, 'Κεντρικός Δρόμος Α1',     'open',   '10 λεπτά'),
  (2, 'Μονοπάτι Β4',             'open',   '20 λεπτά, εναλλακτική'),
  (2, 'Δρόμος Προς Βούνι',       'slow',   'Προσοχή — στενή λωρίδα'),
  (3, 'Κεντρικός Δρόμος',        'open',   '5 λεπτά'),
  (3, 'Βόρεια Διαδρομή',         'open',   'Μέσω λόφου');

-- ─────────────────────────────────────────────────────────
--  NOTIFICATIONS — Ιστορικό push notifications
-- ─────────────────────────────────────────────────────────
CREATE TABLE notifications (
  id         INT AUTO_INCREMENT PRIMARY KEY,
  village_id INT NOT NULL,
  user_id    INT,            -- NULL = προς όλο το χωριό
  title      VARCHAR(200) NOT NULL,
  body       TEXT,
  type       VARCHAR(50),
  data       JSON,
  sent_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (village_id) REFERENCES villages(id)
);

-- ─────────────────────────────────────────────────────────
--  MAP PINS — Σημεία χάρτη (σημεία συνάντησης κλπ)
-- ─────────────────────────────────────────────────────────
CREATE TABLE map_pins (
  id         INT AUTO_INCREMENT PRIMARY KEY,
  village_id INT NOT NULL,
  type       ENUM('meeting','alert','route','hazard') NOT NULL,
  name       VARCHAR(150),
  info       TEXT,
  lat        DECIMAL(10,7) NOT NULL,
  lng        DECIMAL(10,7) NOT NULL,
  active     TINYINT(1) DEFAULT 1,
  FOREIGN KEY (village_id) REFERENCES villages(id)
);

INSERT INTO map_pins (village_id, type, name, info, lat, lng) VALUES
  (1, 'meeting', 'Σημείο Συνάντησης Α', 'Κεντρική πλατεία — 200 άτομα', 34.716, 32.975),
  (2, 'meeting', 'Δημοτικό Σχολείο',   'Ασφαλής τοποθεσία',             34.914, 32.875),
  (3, 'meeting', 'Κεντρική Πλατεία',   'Σημείο συνάντησης demo',        34.906, 33.638);
