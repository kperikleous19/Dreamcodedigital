# 📱 ΧωριόAlert — Οδηγός Ανάπτυξης & Play Store
## Πλήρης οδηγός από το μηδέν ως το Play Store

---

## 📁 ΔΟΜΗ ΑΡΧΕΙΩΝ

```
xorioalert/
├── backend/                    ← Βάζεις αυτό στον web server σου
│   ├── .htaccess
│   ├── config/
│   │   ├── database.php        ← Στοιχεία MySQL
│   │   └── helpers.php         ← JWT + utilities
│   └── api/
│       ├── auth.php            ← POST register/login
│       ├── incidents.php       ← GET/POST/PUT αναφορές
│       ├── sos.php             ← POST SOS alerts
│       ├── map.php             ← GET χάρτης + θέσεις
│       └── notifications.php  ← GET/POST notifications
├── database/
│   └── schema.sql              ← Εκτελείς στη MySQL μία φορά
├── docs/
│   └── GUIDE.md                ← Αυτό το αρχείο
└── village_emergency_app.html  ← Το frontend (θα το μετατρέψεις)
```

---

## 🖥️ ΒΗΜΑ 1: Στήσε τον Server

### Επιλογή Α — Shared Hosting (φθηνότερο, π.χ. Hostinger ~3€/μήνα)
1. Αγόρασε πλάνο με **PHP 8+ και MySQL**
2. Πήγαινε στο **cPanel → File Manager**
3. Ανέβασε τον φάκελο `backend/` στο `public_html/api/`
4. Πήγαινε στο **cPanel → MySQL Databases**
5. Δημιούργησε database `xorioalert` και user
6. Άνοιξε **phpMyAdmin**, επίλεξε τη database, κλίκαρε "Import"
7. Ανέβασε το `schema.sql`

### Επιλογή Β — VPS (π.χ. Hetzner 4€/μήνα, πιο ελεύθερο)
```bash
# Ubuntu 22.04
sudo apt update
sudo apt install apache2 php8.2 php8.2-pdo php8.2-mysql mysql-server -y

# Δημιουργία database
mysql -u root -p
CREATE DATABASE xorioalert;
CREATE USER 'xorioalert_user'@'localhost' IDENTIFIED BY 'STRONG_PASS';
GRANT ALL ON xorioalert.* TO 'xorioalert_user'@'localhost';
FLUSH PRIVILEGES;
exit;

mysql -u xorioalert_user -p xorioalert < schema.sql

# Αντιγραφή backend
sudo cp -r backend/ /var/www/html/
sudo chown -R www-data:www-data /var/www/html/backend/
```

---

## ⚙️ ΒΗΜΑ 2: Ρύθμισε το config/database.php

Άνοιξε `backend/config/database.php` και άλλαξε:

```php
define('DB_HOST', 'localhost');
define('DB_NAME', 'xorioalert');
define('DB_USER', 'xorioalert_user');   // το user που έφτιαξες
define('DB_PASS', 'STRONG_PASSWORD');   // ο κωδικός σου
define('JWT_SECRET', 'abc123xyz...'); // τυχαία 64 χαρακτήρες
```

**Για να φτιάξεις τυχαίο JWT_SECRET:**
```bash
openssl rand -hex 32
```

---

## 🧪 ΒΗΜΑ 3: Τεστ API

Με το Postman ή curl:

```bash
# Test εγγραφή
curl -X POST https://yourdomain.com/backend/api/auth.php?action=register \
  -H "Content-Type: application/json" \
  -d '{"full_name":"Νίκος","email":"test@test.com","village_code":"DEMO2024","password":"123456"}'

# Αποτέλεσμα: {"success":true,"data":{"token":"eyJ...","user":{...},"village":{...}}}

# Test login
curl -X POST https://yourdomain.com/backend/api/auth.php?action=login \
  -H "Content-Type: application/json" \
  -d '{"email":"test@test.com","password":"123456"}'
```

---

## 📱 ΒΗΜΑ 4: Μετατροπή σε Android App (Capacitor)

Αυτό μετατρέπει το HTML app σου σε **πραγματικό .apk / .aab** για Play Store.

### Εγκατάσταση εργαλείων (κάνεις μία φορά):

```bash
# 1. Εγκατάστησε Node.js από https://nodejs.org

# 2. Εγκατάστησε Capacitor
npm install -g @capacitor/cli

# 3. Δημιούργησε project
mkdir xorioalert-app && cd xorioalert-app
npm init -y
npm install @capacitor/core @capacitor/android @capacitor/geolocation @capacitor/push-notifications

# 4. Αρχικοποίηση
npx cap init "ΧωριόAlert" "cy.xorioalert.app" --web-dir dist

# 5. Αντέγραψε το HTML file σου
mkdir dist
cp ../village_emergency_app.html dist/index.html
```

### Ενημέρωσε το `capacitor.config.json`:
```json
{
  "appId": "cy.xorioalert.app",
  "appName": "ΧωριόAlert",
  "webDir": "dist",
  "server": {
    "androidScheme": "https"
  },
  "plugins": {
    "Geolocation": {
      "permissions": ["location"]
    }
  }
}
```

### Build Android:
```bash
# 1. Πρόσθεσε Android platform
npx cap add android

# 2. Sync
npx cap sync android

# 3. Άνοιξε Android Studio
npx cap open android
```

---

## 🔗 ΒΗΜΑ 5: Σύνδεση Frontend με το Backend API

Στο `village_emergency_app.html`, αντικατέστησε τα hardcoded δεδομένα με API calls:

```javascript
// Στην αρχή του <script> πρόσθεσε:
const API_BASE = 'https://YOURDOMAIN.com/backend/api';

// Αντί για hardcoded login, κάνε:
async function doLogin() {
  const res = await fetch(`${API_BASE}/auth.php?action=login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, password })
  });
  const data = await res.json();
  if (data.success) {
    localStorage.setItem('token', data.data.token);
    // ... συνέχεια login
  }
}

// Για authenticated calls:
async function apiFetch(endpoint, options = {}) {
  const token = localStorage.getItem('token');
  return fetch(`${API_BASE}/${endpoint}`, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`,
      ...options.headers
    }
  });
}
```

---

## 🏪 ΒΗΜΑ 6: Δημοσίευση στο Play Store

### 6.1 Δημιούργησε Google Play Developer Account
- Πήγαινε: https://play.google.com/console
- Πλήρωσε εφάπαξ **$25 USD**
- Επαλήθευσε την ταυτότητά σου

### 6.2 Δημιούργησε Signed APK/AAB στο Android Studio:
```
Build → Generate Signed Bundle/APK
→ Android App Bundle (.aab) — προτιμώ αυτό
→ Create new keystore (φύλαξε το keystore αρχείο!)
→ Release
```

### 6.3 Στο Play Console:
1. **Create app** → εφαρμογή → Ελληνικά + Αγγλικά
2. **Συμπλήρωσε:**
   - Τίτλος: "ΧωριόAlert - Έκτακτη Ανάγκη"
   - Σύντομη περιγραφή (80 χαρακτήρες)
   - Πλήρης περιγραφή (4000 χαρακτήρες)
3. **Εικόνες:** Icon 512x512px, Screenshots τηλεφώνου, Feature graphic 1024x500px
4. **Content rating:** Συμπλήρωσε το ερωτηματολόγιο
5. **Production** → Upload .aab → Submit for review

### 6.4 Χρόνος αναμονής:
- Νέες εφαρμογές: **7-14 ημέρες** για review
- Ενημερώσεις: 1-3 ημέρες

---

## 🔔 ΒΗΜΑ 7: Push Notifications (Firebase)

Για πραγματικά push notifications στα τηλέφωνα:

1. Πήγαινε: https://console.firebase.google.com
2. Δημιούργησε project "xorioalert"
3. Πρόσθεσε Android app με package name `cy.xorioalert.app`
4. Κατέβασε `google-services.json` → βάλε το στο `android/app/`
5. Στο PHP backend, στείλε notifications:

```php
function sendFirebasePush(array $tokens, string $title, string $body): void {
    $serverKey = 'YOUR_FIREBASE_SERVER_KEY'; // από Firebase Console
    $data = [
        'registration_ids' => $tokens,
        'notification' => ['title' => $title, 'body' => $body],
        'priority' => 'high',
    ];
    $ch = curl_init('https://fcm.googleapis.com/fcm/send');
    curl_setopt_array($ch, [
        CURLOPT_POST => true,
        CURLOPT_HTTPHEADER => ["Authorization: key=$serverKey", "Content-Type: application/json"],
        CURLOPT_POSTFIELDS => json_encode($data),
        CURLOPT_RETURNTRANSFER => true,
    ]);
    curl_exec($ch);
    curl_close($ch);
}
```

---

## 💰 ΚΟΣΤΟΣ ΣΥΝΟΛΙΚΑ

| Στοιχείο | Κόστος |
|----------|--------|
| Web Hosting (Hostinger Basic) | ~3-5€/μήνα |
| Domain (.com ή .cy) | 10-15€/χρόνο |
| Google Play Developer | $25 εφάπαξ |
| SSL Certificate | Δωρεάν (Let's Encrypt) |
| Firebase | Δωρεάν (έως 1M notifications/μήνα) |
| **Σύνολο πρώτου χρόνου** | **~80-100€** |

---

## ✅ CHECKLIST ΠΡΙΝ ΤΟ PLAY STORE

- [ ] Backend τρέχει και APIs δουλεύουν
- [ ] HTTPS ενεργό (SSL certificate)
- [ ] JWT_SECRET έχει αλλαχτεί σε τυχαίο string
- [ ] App συνδέεται με το backend
- [ ] GPS permissions δουλεύουν στο κινητό
- [ ] Push notifications δουλεύουν
- [ ] Icon 512x512px έτοιμο
- [ ] Screenshots 2-8 εικόνες
- [ ] Privacy Policy URL (υποχρεωτικό για Play Store)
- [ ] Εγγραφή/σύνδεση δουλεύει με πραγματικό API
